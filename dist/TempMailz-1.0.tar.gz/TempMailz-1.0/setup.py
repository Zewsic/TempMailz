from setuptools import setup

setup(name='TempMailz',
      version='1.0',
      description='The module allows you to interact with temporary mail',
      packages=['TempMailz'],
      author_email='danilanicishin@gmail.com',
      zip_safe=False)